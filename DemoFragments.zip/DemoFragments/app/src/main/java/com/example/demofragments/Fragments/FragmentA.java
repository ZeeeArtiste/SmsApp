package com.example.demofragments.Fragments;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager.widget.ViewPager;

import com.example.demofragments.Contact;
import com.example.demofragments.ContactAdapter;
import com.example.demofragments.MainActivity;
import com.example.demofragments.R;

import java.util.ArrayList;
import java.util.HashMap;

public class FragmentA extends Fragment {

    private ListView listView;
    private Button button;
    private ArrayList<Contact> selectedContacts = new ArrayList<>();
    private OnContactsSelectedListener listener;
    private FragmentManager fragmentManager;
    private FragmentB fragmentB;
    private ContactAdapter adapter;
    private ArrayList<Contact> allContacts = new ArrayList<>();


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        fragmentManager = getParentFragmentManager();
        fragmentB = new FragmentB();
        try {
            listener = (OnContactsSelectedListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString() + " pas de OnContactsSelectedListener");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_a, container, false);
        listView = view.findViewById(R.id.list_view_contacts);
        button = view.findViewById(R.id.button_next);
        allContacts = getContacts();
        // Affichage des contacts dans la liste
        adapter = new ContactAdapter(getContext(), (ArrayList<Contact>) allContacts, selectedContacts);
        listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        listView.setAdapter(adapter);

        // Gestion du clic sur le bouton pour passer au fragment B
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedContacts.size() > 0) {
                    listener.onContactsSelected(selectedContacts);
                    // Send the selected contacts to the MainActivity
                    ViewPager viewPager = getActivity().findViewById(R.id.view_pager);
                    // Autoriser le swipe vers la droite
                    MainActivity.setOldPosition(viewPager.getCurrentItem()+1);
                    viewPager.setCurrentItem(1);
                }
                 else {
                    Toast.makeText(getContext(), "Il faut séléctionner au moins un contact !", Toast.LENGTH_SHORT).show();
                }
            }
        });
        return view;
    }

    public interface OnContactsSelectedListener {
        void onContactsSelected(ArrayList<Contact> selectedContacts);
    }


    // Rretourne la liste de contacts de l'utilisateur
    private ArrayList<Contact> getContacts() {
        ArrayList<Contact> contacts = new ArrayList<>();
        // Récupération du ContentResolver de l'application en cours d'exécution
        ContentResolver contentResolver = getContext().getContentResolver();
        // Récupérer tous les contacts de l'utilisateur triés par nom
        Cursor cursor = contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC");

        if (cursor != null && cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                // Récupération du nom et du numéro de téléphone du contact
                String name = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                String phoneNumber = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER));
                // Création d'un objet Contact à partir des informations récupérées
                Contact contact = new Contact(name, phoneNumber);
                // Ajout du contact à la liste de contacts
                contacts.add(contact);
            }
        }

        // Fermeture du curseur s'il est ouvert
        if (cursor != null) {
            cursor.close();
        }
        // Retourne la liste de contacts
        return contacts;
    }






}
