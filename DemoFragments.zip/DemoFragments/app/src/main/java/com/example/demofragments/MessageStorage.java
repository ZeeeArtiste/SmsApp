package com.example.demofragments;

import android.content.Context;
import android.util.Log;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MessageStorage {
    private Context context;
    public MessageStorage(Context context) {
        this.context = context;
    }
    private static final String FILENAME = "messages.txt";

    public void saveMessages(ArrayList<String> messages) {
        FileOutputStream outputStream = null;
        // Récupérer fichier ou le créer
        try {
            outputStream = this.context.openFileOutput(FILENAME, Context.MODE_PRIVATE);
            // Ecrire dedans
            for (String message : messages) {
                outputStream.write(message.getBytes());
                outputStream.write(System.getProperty("line.separator").getBytes());
            }
            Log.d("MessageStorage", "Messages sauvegardés.");
        } catch (IOException e) {
            Log.e("MessageStorage", "Erreur", e);
        } finally {
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                    Log.e("MessageStorage", "Erreur", e);
                }
            }
        }
    }

    public List<String> loadMessages() {
        ArrayList<String> messages = new ArrayList<>();
        FileInputStream inputStream = null;
        // Récupérer messages
        try {
            inputStream = this.context.openFileInput(FILENAME);
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            String line;
            // Srocker messages
            while ((line = bufferedReader.readLine()) != null) {
                messages.add(line);
            }
            Log.d("MessageStorage", "Messages ok.");
        } catch (IOException e) {
            Log.e("MessageStorage", "Erreur", e);
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    Log.e("MessageStorage", "Erreur", e);
                }
            }
        }
        return messages;
    }
}
