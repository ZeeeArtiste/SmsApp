package com.example.demofragments.Fragments;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.example.demofragments.Contact;
import com.example.demofragments.MainActivity;
import com.example.demofragments.R;

import java.util.ArrayList;

public class FragmentC extends Fragment {

    private TextView selectedContactsTextView;
    private TextView selectedMessageTextView;
    private ArrayList selectedContactsList;
    private ArrayList<Contact> selectedContacts = new ArrayList<>();
    private String selectedMessage;
    private MainActivity mainActivity;
    private Button sendSMSButton;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_c, container, false);

        mainActivity = (MainActivity) getActivity();
        selectedContactsTextView = view.findViewById(R.id.selectedContactsTextView);
        selectedMessageTextView = view.findViewById(R.id.selectedMessageTextView);
        sendSMSButton = view.findViewById(R.id.sendMessageButton);

        // Récupérer les données choisis par l'utilisateur
        selectedContacts = mainActivity.getContacts();
        selectedMessage = mainActivity.getMessage();

        // Restauration au cas où
        if (savedInstanceState != null) {
            selectedContactsList = savedInstanceState.getStringArrayList("selectedContactsList");
            selectedMessage = savedInstanceState.getString("selectedMessage");
        }
        updateViews();

        sendSMSButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendSMS();
            }
        });
        return view;
    }

    // Mettre à jour les données de la vue
    private void updateViews() {
        selectedContacts = mainActivity.getContacts();
        selectedMessage = mainActivity.getMessage();
        updateSelectedContactsTextView();
        updateSelectedMessageTextView();
    }

    @Override
    public void onResume() {
        super.onResume();
        updateViews();
    }

    // Enregistrer les données de l'état actuel du fragment
    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putStringArrayList("selectedContactsList", (ArrayList<String>) selectedContactsList);
        outState.putString("selectedMessage", selectedMessage);
    }

    // Afficher les contact séléctionnés dans la vue
    private void updateSelectedContactsTextView() {
        if (this.selectedContacts != null && !this.selectedContacts.isEmpty()) {
            StringBuilder contactsBuilder = new StringBuilder();
            for (Contact contact : selectedContacts) {
                contactsBuilder.append(contact.getName()).append(", ");
            }
            String contactsString = contactsBuilder.substring(0, contactsBuilder.length() - 2); // remove last comma and space
            selectedContactsTextView.setText(getString(R.string.nom_du_contact, contactsString));
        } else {
            selectedContactsTextView.setText(getString(R.string.no_contacts_selected));
        }
    }

    // Afficher les messages séléctionnés dans la vue
    void updateSelectedMessageTextView() {
        if (this.selectedMessage != null && !this.selectedMessage.isEmpty()) {
            selectedMessageTextView.setText(getString(R.string.message_selectionne, this.selectedMessage));
        } else {
            selectedMessageTextView.setText(getString(R.string.no_message_selected));
        }
    }

    //Envoyer le SMSs
    private void sendSMS() {
        if (selectedContacts != null && !selectedContacts.isEmpty() && selectedMessage != null && !selectedMessage.isEmpty()) {
            StringBuilder phoneNumberBuilder = new StringBuilder();
            for (Contact contact : selectedContacts) {
                phoneNumberBuilder.append(contact.getPhoneNumber()).append(";");
            }
            String phoneNumber = phoneNumberBuilder.substring(0, phoneNumberBuilder.length() - 1); // remove last semicolon
            SmsManager smsManager = SmsManager.getDefault();
            ArrayList<String> parts = smsManager.divideMessage(selectedMessage);
            for (String phoneNumberPart : phoneNumber.split(";")) {
                smsManager.sendMultipartTextMessage(phoneNumberPart, null, parts, null, null);
            }
            Toast.makeText(getActivity(), "Message(s) envoyé", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getActivity(), "Il faut au moins un message et un contact...", Toast.LENGTH_SHORT).show();
        }
    }

}