package com.example.demofragments;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.content.pm.PackageManager;
import android.os.Bundle;
import android.Manifest;
import android.view.MotionEvent;
import android.view.View;

import com.example.demofragments.Fragments.FragmentA;
import com.example.demofragments.Fragments.FragmentB;
import com.example.demofragments.Fragments.FragmentC;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements FragmentA.OnContactsSelectedListener, FragmentB.OnMessageSelectedListener {
    private ViewPager viewPager;
    private TabLayout tabLayout;
    private ArrayList<Contact> contactSelected = new ArrayList<>();
    private String messageToSend;
    private static final int PERMISSIONS_REQUEST_CONTACTS_AND_SMS = 1;
    private static int oldPosition=0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Vérification des permissions
        if(!hasPermissions()){
            requestPermissions();
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Création des fragments pour chaque onglet
        List<Fragment> fragments = new ArrayList<>();
        fragments.add(new FragmentA());
        fragments.add(new FragmentB());
        fragments.add(new FragmentC());

        // Création de l'adapter pour les fragments
        FragmentPagerAdapter adapter = new FragmentPagerAdapter(getSupportFragmentManager()) {
            @Override
            public Fragment getItem(int position) {
                return fragments.get(position);
            }

            @Override
            public int getCount() {
                return fragments.size();
            }

            @Override
            public CharSequence getPageTitle(int position) {
                switch (position) {
                    case 0:
                        return "Séléction destinataire(s)";
                    case 1:
                        return "Séléction du message";
                    case 2:
                        return "Récapitulatif";
                    default:
                        return null;
                }
            }
        };

        // Récupération de la vue ViewPager et TabLayout du layout
        viewPager = findViewById(R.id.view_pager);

        tabLayout = findViewById(R.id.tabs);
        // Désactiver l'interaction avec le TabLayout
        tabLayout.setupWithViewPager(null);

        // Configuration de l'adapter pour le ViewPager
        viewPager.setAdapter(adapter);
        // Ajout des onglets au TabLayout
        tabLayout.setupWithViewPager(viewPager, false);

        // Désactiver tous les onglets
        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            tabLayout.getTabAt(i).view.setClickable(false);
        }

        oldPosition = viewPager.getCurrentItem();
        //Gestion des évènements de la page
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            // Forcer l'actualisation du fragment C
            @Override
            public void onPageSelected(int position) {
                if (position == 2) {
                    FragmentC fragmentC = (FragmentC) adapter.instantiateItem(viewPager, position);
                    fragmentC.onResume();
                }
                // Empêcher de changer de fragment vers la droite sans passer par les boutons
                if(position!=oldPosition && oldPosition<viewPager.getCurrentItem()){
                    viewPager.setCurrentItem(oldPosition);
                }else {
                    oldPosition=viewPager.getCurrentItem();
                }
            }
            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });

    }

    //Met à jour les contacts séléctionnés
    @Override
    public void onContactsSelected(ArrayList<Contact> selectedContacts) {
        contactSelected = selectedContacts;
    }

    //Met à jour le message séléctionné
    @Override
    public void onMessageSelected(String selectedMessage) {
        messageToSend = selectedMessage;
    }

    public ArrayList<Contact> getContacts() {
        return contactSelected;
    }

    public String getMessage() {
        return messageToSend;
    }

    // Vérifie si l'application a déjà obtenu la permission d'accéder aux contacts et à l'envoi de SMS
    private boolean hasPermissions() {
        int readContactsPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS);
        int sendSmsPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS);

        return readContactsPermission == PackageManager.PERMISSION_GRANTED && sendSmsPermission == PackageManager.PERMISSION_GRANTED;
    }

    // Demande à l'utilisateur la permission d'accéder aux contacts et à l'envoi de SMS
    private void requestPermissions() {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_CONTACTS, Manifest.permission.SEND_SMS},
                    PERMISSIONS_REQUEST_CONTACTS_AND_SMS);
    }

    // Gérer les swipe autorisés
    public static void setOldPosition(int position){
        oldPosition = position;
    }
}
