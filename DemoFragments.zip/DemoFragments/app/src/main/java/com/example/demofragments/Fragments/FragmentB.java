package com.example.demofragments.Fragments;

import static com.google.android.material.internal.ContextUtils.getActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager.widget.ViewPager;

import com.example.demofragments.MainActivity;
import com.example.demofragments.MessageStorage;
import com.example.demofragments.R;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FragmentB extends Fragment {

    private ListView listView;
    private Button nextButton;
    ArrayList<String> messages = new ArrayList<>();
    private ArrayList<String> customMessages = new ArrayList<>();
    private ArrayList<String> messagesToSave = new ArrayList<>();
    private OnMessageSelectedListener listener;
    private MessageStorage messageStorage;
    private FragmentC fragmentC;
    private FragmentManager fragmentManager;
    private String messageSelected;



    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        fragmentManager = getParentFragmentManager();
        fragmentC = new FragmentC();
        try {
            listener = (OnMessageSelectedListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString() + " pas de OnMessageSelectedListener");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_b, container, false);

        // Gestion des messages à enregistrer
        messageStorage = new MessageStorage(getActivity());
        messages.add("Je te répond plus tard.");
        messagesToSave.addAll(messageStorage.loadMessages());
        messages.addAll(messagesToSave);

        listView = view.findViewById(R.id.list_view);
        nextButton = view.findViewById(R.id.button);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_single_choice, messages);
        listView.setAdapter(adapter);
        listView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        // Gestion du clique sur un message
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                messageSelected = messages.get(position);
            }
        });

        Button addButton = view.findViewById(R.id.btn_add_message);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Ouvrir un AlertDialog pour saisir le nouveau message
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setTitle("Nouveau message personnalisé");

                // Ajouter un champ de saisie
                final EditText input = new EditText(getActivity());
                input.setInputType(InputType.TYPE_CLASS_TEXT);
                builder.setView(input);

                // Ajouter un bouton "Ajouter"
                builder.setPositiveButton("Ajouter", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Ajouter le nouveau message à la liste de messages personnalisés
                        String newMessage = input.getText().toString();
                        customMessages.add(newMessage);
                        updateList();
                    }
                });
                // Ajouter un bouton "Annuler"
                builder.setNegativeButton("Annuler", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                // Afficher le dialogue
                builder.show();
            }
        });

        // Gestion du clic sur le bouton pour passer au fragment C
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ViewPager viewPager = getActivity().findViewById(R.id.view_pager);
                // Autoriser le swipe vers la droite
                MainActivity.setOldPosition(viewPager.getCurrentItem()+1);
                listener.onMessageSelected(messageSelected);
                viewPager.setCurrentItem(2);
            }
        });
        return view;
    }

    // Mettre à jour la liste de messages à afficher
    private void updateList() {
        messages.addAll(customMessages);
        messagesToSave.addAll(customMessages);
        messageStorage.saveMessages(messagesToSave);
        ArrayAdapter<String>  adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_single_choice, messages);
        listView.setAdapter(adapter);
    }
    public interface OnMessageSelectedListener {
        void onMessageSelected(String selectedMessage);
    }
}
