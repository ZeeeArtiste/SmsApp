package com.example.demofragments;

import android.content.Context;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.demofragments.Contact;
import com.example.demofragments.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ContactAdapter extends ArrayAdapter<Contact> {
    private ArrayList<Contact> contacts;
    private ArrayList<Contact> selectedContacts;
    public ContactAdapter(Context context, ArrayList<Contact> contacts, ArrayList<Contact> selectedContacts) {
        super(context, 0, contacts);
        this.contacts = contacts;
        this.selectedContacts = selectedContacts;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Vérifie si la vue existe déjà pour cet élément
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.contact_item, parent, false);
        }

        // Récupère le Contact à partir de la liste des contacts
        final Contact contact = getItem(position);

        // Récupère les éléments de la vue
        TextView nameTextView = convertView.findViewById(R.id.textViewName);
        TextView phoneTextView = convertView.findViewById(R.id.textViewNumber);
        CheckBox checkBox = convertView.findViewById(R.id.checkBoxContact);

        // Affiche le nom et le numéro de téléphone du contact dans les TextView correspondantes
        nameTextView.setText(contact.getName());
        phoneTextView.setText(contact.getPhoneNumber());

        // Coche la CheckBox si le contact est sélectionné
        checkBox.setChecked(selectedContacts.contains(contact));

        // Gestion de la CheckBox pour ajouter ou supprimer le contact
        checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isChecked = ((CheckBox) v).isChecked();
                if (isChecked) {
                    selectedContacts.add(contact);
                } else {
                    selectedContacts.remove(contact);
                }
            }
        });
        return convertView;
    }
}

